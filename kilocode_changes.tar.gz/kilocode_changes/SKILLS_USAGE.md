# Claude Code Skills 使用指南

## 概述

Claude Code Skills 是 Kilo Code 的一个强大功能,允许您通过自定义技能扩展 AI 代理的能力。Skills 采用渐进式披露设计模式,Agent 知道技能的存在,但只在需要时读取完整内容,保持上下文高效。

## 功能特点

- ✅ **渐进式披露**: Agent 先知道技能存在,需要时再读取完整内容
- ✅ **模块化设计**: 每个技能是独立的目录,包含 SKILL.md 和支持文件
- ✅ **层级覆盖**: 项目级技能优先于用户级技能(同名时)
- ✅ **安全保护**: 多重防护防止路径遍历和注入攻击
- ✅ **自动加载**: 启动任务时自动加载已启用的技能

## 目录结构

### 用户级 Skills
位置: `~/.kilocode/skills/`

用于个人常用的技能,可在所有项目中使用。

```
~/.kilocode/skills/
├── web-research/
│   ├── SKILL.md           # 技能定义文件
│   ├── config.json        # 可选配置
│   └── scripts/           # 支持脚本
│       └── search.py
└── data-analysis/
    └── SKILL.md
```

### 项目级 Skills
位置: `<project-root>/.kilocode/skills/`

用于项目特定的技能,只在当前项目中使用。

```
<project-root>/.kilocode/skills/
├── project-tool/
│   └── SKILL.md
└── custom-workflow/
    └── SKILL.md
```

## SKILL.md 文件格式

每个技能必须包含一个 `SKILL.md` 文件,格式如下:

```markdown
---
name: skill-name
description: Brief description of what this skill does
version: 1.0.0
author: your-name@example.com
tags: [tag1, tag2, tag3]
---

# Skill Name

## When to Use
- Describe when this skill should be used
- List specific scenarios or triggers

## How to Use

### Step 1: Planning
- Define objectives
- Identify key requirements

### Step 2: Execution
- Implement the workflow
- Use appropriate tools

### Step 3: Verification
- Validate results
- Ensure quality

## Examples

### Example 1: Basic Usage
**User Request**: "Example request"

**Execution**:
1. First step
2. Second step
3. Third step

## Best Practices
- Follow best practices
- Consider edge cases
- Document your work
```

### 必需字段

在 YAML frontmatter 中:
- `name`: 技能名称(只能包含字母、数字、连字符、下划线)
- `description`: 技能描述

### 可选字段

- `version`: 版本号
- `author`: 作者信息
- `tags`: 标签数组

## 创建新技能

### 方法 1: 手动创建

1. 创建技能目录:
```bash
mkdir -p ~/.kilocode/skills/my-skill
```

2. 创建 SKILL.md 文件:
```bash
cat > ~/.kilocode/skills/my-skill/SKILL.md << 'EOF'
---
name: my-skill
description: Description of my skill
version: 1.0.0
tags: [custom]
---

# My Skill

## When to Use
- When user asks for X
- When situation Y occurs

## How to Use
[Your workflow here]
EOF
```

### 方法 2: 通过 Webview 消息(需要 UI 实现)

```typescript
// 发送创建技能消息
vscode.postMessage({
  type: 'createSkill',
  skillName: 'my-skill',
  skillLocation: 'user' // 或 'project'
})
```

## 使用技能

### 自动加载

启用 `kilo-code.skills.autoLoad` 配置后,技能会在任务启动时自动加载到系统提示中。

### 手动启用/禁用

通过 Webview 消息:

```typescript
// 启用技能
vscode.postMessage({
  type: 'enableSkill',
  skillName: 'web-research'
})

// 禁用技能
vscode.postMessage({
  type: 'disableSkill',
  skillName: 'web-research'
})
```

### Agent 使用流程

1. **发现**: Agent 在系统提示中看到可用的技能列表
2. **识别**: 根据用户请求,识别适用的技能
3. **读取**: 使用 `read_file` 工具读取 `SKILL.md` 的完整内容
4. **执行**: 按照技能指令执行任务
5. **验证**: 验证结果是否符合技能要求

## VS Code 配置

在 VS Code 设置中配置 Skills:

```json
{
  "kilo-code.skills.enabled": true,
  "kilo-code.skills.userDirectory": "~/.kilocode/skills",
  "kilo-code.skills.projectDirectory": ".kilocode/skills",
  "kilo-code.skills.autoLoad": true,
  "kilo-code.skills.maxFileSize": 10485760
}
```

### 配置说明

- **enabled**: 启用/禁用 Skills 功能
- **userDirectory**: 用户级技能目录路径
- **projectDirectory**: 项目级技能目录路径(相对于工作区根目录)
- **autoLoad**: 是否自动加载技能
- **maxFileSize**: SKILL.md 文件的最大大小(字节,默认 10MB)

## 示例技能

项目包含三个示例技能:

### 1. Web Research (`examples/skills/web-research/`)
结构化的网络研究方法,包括:
- 研究规划
- 信息收集
- 结果综合
- 来源验证

### 2. Code Review (`examples/skills/code-review/`)
系统化的代码审查流程,检查:
- 代码质量
- 架构设计
- 安全性
- 性能
- 测试覆盖

### 3. API Design (`examples/skills/api-design/`)
RESTful API 设计最佳实践,包括:
- 资源命名
- HTTP 方法使用
- 状态码
- 响应格式
- 版本控制

## 安全考虑

### 路径安全

- 技能名称只能包含: `a-zA-Z0-9_-`
- 禁止路径遍历字符: `..`, `/`, `\`
- 所有路径都会验证是否在允许的目录内

### 文件大小限制

- 默认最大 10MB
- 可通过配置调整
- 防止加载过大文件影响性能

### 符号链接检查

- 自动检测符号链接
- 验证符号链接指向的路径安全性
- 防止通过符号链接访问外部文件

## 最佳实践

### 技能设计

1. **专注单一领域**: 每个技能解决特定类型的任务
2. **清晰文档**: 提供详细的使用说明和示例
3. **完整元数据**: 确保 name 和 description 准确
4. **支持文件**: 包含必要的脚本和配置文件

### 技能使用

1. **合理命名**: 使用描述性的技能名称
2. **标签分类**: 使用标签帮助组织和查找
3. **版本管理**: 为技能添加版本号
4. **文档更新**: 保持技能文档与实现同步

### 性能优化

1. **控制大小**: 保持 SKILL.md 文件简洁
2. **缓存利用**: 系统会自动缓存技能内容(5分钟 TTL)
3. **按需加载**: 只启用需要的技能

## 故障排查

### 技能未加载

1. 检查 `kilo-code.skills.enabled` 是否为 true
2. 验证技能目录路径是否正确
3. 确认 SKILL.md 文件格式正确
4. 查看 VS Code 输出面板中的错误信息

### 技能无法识别

1. 检查 SKILL.md 的 frontmatter 格式
2. 确认 name 和 description 字段存在
3. 验证技能名称符合命名规则
4. 尝试刷新技能缓存

### 权限问题

1. 确保技能目录有读取权限
2. 检查 SKILL.md 文件权限
3. 验证符号链接指向的文件权限

## Webview API

### 消息类型

**发送到扩展**:
- `listSkills`: 列出所有可用技能
- `getSkillContent`: 获取技能完整内容
- `enableSkill`: 启用技能
- `disableSkill`: 禁用技能
- `createSkill`: 创建新技能
- `deleteSkill`: 删除技能
- `refreshSkills`: 刷新技能缓存

**从扩展接收**:
- `skillsList`: 技能列表
- `skillContent`: 技能内容
- `skillEnabled`: 技能已启用
- `skillDisabled`: 技能已禁用
- `skillCreated`: 技能已创建
- `skillDeleted`: 技能已删除
- `skillError`: 错误信息

### 示例代码

```typescript
// 列出所有技能
vscode.postMessage({ type: 'listSkills' })

// 监听响应
window.addEventListener('message', (event) => {
  const message = event.data
  switch (message.type) {
    case 'skillsList':
      console.log('Available skills:', message.skills)
      break
    case 'skillError':
      console.error('Error:', message.error)
      break
  }
})
```

## 未来扩展

### 计划功能

- **Skills 市场**: 分享和下载社区技能
- **Skills 模板**: 更多内置模板
- **依赖管理**: 技能之间的依赖关系
- **版本控制**: 技能版本管理和更新
- **性能分析**: 技能使用统计和分析

### 贡献

欢迎贡献新的示例技能或改进现有功能!

## 参考资料

- [Anthropic Agent Skills 设计模式](https://docs.anthropic.com/en/docs/build-with-claude/agent-skills)
- [Kilo Code 文档](https://kilo.ai/docs)
- [技术规格文档](./CLAUDE_CODE_SKILLS_SPEC.md)

## 许可证

本功能遵循 Kilo Code 项目的许可证。
