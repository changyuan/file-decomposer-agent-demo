# Kilo Code 项目上下文

## 项目概述

**Kilo Code** 是一个开源的 AI 编码代理平台，为 VS Code 提供智能代码生成、任务自动化和多模型支持能力。它是 OpenRouter 排名第一的编码助手，拥有超过 75 万用户，每月使用超过 6.1 万亿个 token。

### 核心特性

- ✨ **自然语言代码生成**：通过自然语言描述生成代码
- ✅ **自我检查**：自动验证生成的代码质量
- 🧪 **终端命令执行**：直接运行和测试命令
- 🌐 **浏览器自动化**：自动化浏览器操作
- 🤖 **多模型支持**：支持 500+ AI 模型（包括 Gemini 3 Pro、Claude 4.5 Sonnet & Opus、GPT-5）
- 🎁 **可选 API 密钥**：提供灵活的认证方式
- 💡 **多模式工作流**：Architect（规划）、Coder（编码）、Debugger（调试）及自定义模式

## 技术栈

### 核心技术

- **运行环境**：Node.js 20.19.2
- **包管理器**：pnpm 10.8.1
- **构建工具**：Turbo (Monorepo 构建系统)
- **主要语言**：TypeScript 5.8.3
- **打包工具**：esbuild 0.25.0
- **测试框架**：Vitest 3.2.3

### 项目架构

这是一个 **Monorepo** 项目，使用 pnpm workspace 和 Turbo 进行管理，主要包含以下模块：

```
kilocode/
├── src/                    # VS Code 扩展核心代码
│   ├── core/              # 核心功能和工具
│   ├── services/          # 服务实现
│   └── extension.ts       # 扩展入口
├── webview-ui/            # 前端 UI 代码（React）
├── cli/                   # CLI 工具
├── packages/              # 共享包
│   ├── build/            # 构建配置
│   ├── cloud/            # 云服务集成
│   ├── config-eslint/    # ESLint 配置
│   ├── config-typescript/# TypeScript 配置
│   ├── evals/            # 评估工具
│   ├── ipc/              # 进程间通信
│   ├── telemetry/        # 遥测数据
│   └── types/            # 类型定义
├── apps/                  # 应用程序
│   ├── kilocode-docs/    # 文档网站
│   ├── playwright-e2e/   # E2E 测试
│   ├── storybook/        # 组件展示
│   ├── vscode-e2e/       # VS Code E2E 测试
│   └── web-roo-code/     # Web 版本
├── jetbrains/            # JetBrains IDE 插件
└── deps/                 # 依赖项（包括 VS Code fork）
```

## 开发环境设置

### 前置要求

选择以下任一开发环境：

#### 选项 1：原生开发（推荐 macOS/Linux/WSL）

1. **Git** - 版本控制
2. **Git LFS** - 大文件存储（必需，用于处理 GIF、MP4 等二进制资源）
3. **Node.js** v20.19.2（推荐使用 `.nvmrc` 指定的版本）
4. **pnpm** - 包管理器
5. **Visual Studio Code** - 推荐的 IDE

#### 选项 2：Devcontainer（推荐 Windows）

1. **Git** + **Git LFS**
2. **Docker Desktop**
3. **Visual Studio Code**
4. **Dev Containers 扩展**

#### 选项 3：Nix Flake（推荐 NixOS/Nix 用户）

1. **Git** + **Git LFS**
2. **Nix**（启用 flakes）
3. **direnv**
4. **Visual Studio Code**

### 安装步骤

```bash
# 1. 克隆仓库
git clone https://github.com/Kilo-Org/kilocode.git
cd kilocode

# 2. 设置 Git LFS
git lfs install
git lfs pull

# 3. 安装依赖
pnpm install
```

### 必需的 VS Code 扩展

- **必需**：[ESBuild Problem Matchers](https://marketplace.visualstudio.com/items?itemName=connor4312.esbuild-problem-matchers)
- **推荐**：ESLint、Prettier

## 核心开发命令

### 开发和调试

```bash
# 启动开发模式（按 F5 或在 VS Code 中选择 Run > Start Debugging）
# 这将打开一个加载了 Kilo Code 的新 VS Code 窗口

# 热重载说明：
# - Webview UI 更改：立即生效
# - 核心扩展更改：自动重载（开发模式下）
```

### 构建和打包

```bash
# 构建生产版本的 .vsix 文件
pnpm build                    # 等同于 pnpm vsix

# 其他构建命令
pnpm bundle                   # 打包扩展
pnpm bundle:nightly           # 打包 nightly 版本
pnpm vsix:production          # 强制构建生产版本
pnpm vsix:nightly             # 构建 nightly 版本

# 安装构建的扩展
pnpm install:vsix             # 安装最新构建的 .vsix
# 或手动安装：
code --install-extension "$(ls -1v bin/kilo-code-*.vsix | tail -n1)"
```

### 测试

```bash
# 运行所有测试
pnpm test

# 运行特定工作区的测试
cd src && pnpm test path/to/test-file          # 后端测试
cd webview-ui && pnpm test src/path/to/test-file  # UI 测试

# E2E 测试
pnpm playwright

# 注意：测试必须从包含 vitest 的 package.json 所在目录运行
```

### 代码质量检查

```bash
# 运行 ESLint
pnpm lint

# 运行 TypeScript 类型检查
pnpm check-types

# 格式化代码
pnpm format

# 检查未使用的依赖
pnpm knip
```

### CLI 相关命令

```bash
pnpm cli:build               # 构建 CLI
pnpm cli:bundle              # 打包 CLI
pnpm cli:deps                # 安装 CLI 依赖
pnpm cli:dev                 # CLI 开发模式
pnpm cli:run                 # 运行 CLI
```

### 文档

```bash
pnpm docs:start              # 启动文档开发服务器
pnpm docs:build              # 构建文档
```

### 清理

```bash
pnpm clean                   # 清理所有构建产物
```

## 开发约定

### 测试规范

1. **测试覆盖率**：
   - 在尝试完成之前，确保代码更改有测试覆盖
   - 提交更改前确保所有测试通过
   - 使用 Vitest 框架（`vi`、`describe`、`test`、`it` 等函数已在 `tsconfig.json` 中定义，无需导入）

2. **测试文件命名**：
   - Monorepo 默认：`.spec.ts` / `.spec.tsx`
   - CLI 包例外：`.test.ts` / `.test.tsx`（匹配现有 CLI 约定）

3. **测试执行**：
   - 必须从正确的工作区运行测试
   - 不要从项目根目录运行测试（会导致 "vitest: command not found" 错误）

### 代码规范

1. **Lint 规则**：
   - 未经明确用户批准，不得禁用任何 lint 规则

2. **样式指南**：
   - 对新标记使用 Tailwind CSS 类，而不是内联样式对象
   - VSCode CSS 变量必须在使用前添加到 `webview-ui/src/index.css`
   - 示例：`<div className="text-md text-vscode-descriptionForeground mb-2" />` 而不是样式对象

### Git Hooks

项目使用 [Husky](https://typicode.github.io/husky/) 管理 Git hooks：

- **Pre-commit**：
  1. 防止直接提交到 `main` 分支
  2. 运行类型生成
  3. 检查类型文件更改
  4. 运行 lint-staged

- **Pre-push**：
  1. 防止直接推送到 `main` 分支
  2. 运行类型检查
  3. 检查 changeset 文件

## 自定义模式

项目支持自定义模式（定义在 `.kilocodemodes`）：

- **Translate 模式**：专注于翻译和本地化文件管理
- **Test 模式**：Jest/Vitest 测试专家，专注于编写和维护测试套件

## 常见问题排查

### 常见问题

1. **扩展未加载**：检查 VS Code 开发者工具（Help > Toggle Developer Tools）中的错误
2. **Webview 未更新**：尝试重新加载窗口（Developer: Reload Window）
3. **构建错误**：确保使用 `pnpm install` 安装了所有依赖
4. **Ripgrep 缺失**：项目捆绑了 `@vscode/ripgrep`，如果缺失会回退到系统 PATH 中的 `rg`

### 调试技巧

- 在代码中使用 `console.log()` 进行调试
- 检查 VS Code 输出面板（View > Output），从下拉菜单中选择 "Kilo Code"
- 对于 webview 问题，使用浏览器开发者工具（右键 > "Inspect Element"）

### 本地后端测试

要针对本地 Kilo Code 后端测试扩展：

1. 在 `http://localhost:3000` 设置本地后端
2. 使用 "Run Extension [Local Backend]" 启动配置（在 Run and Debug 中选择）
3. 按 F5 开始调试

这会自动设置 `KILOCODE_BACKEND_BASE_URL` 环境变量。

## 版本发布

```bash
# 版本管理
pnpm changeset:version        # 更新版本并生成 CHANGELOG

# 发布
pnpm publish:marketplace      # 发布到 VS Code Marketplace 和 Open VSX
```

## 贡献指南

欢迎为 Kilo Code 做出贡献！您可以：

1. **报告问题**：使用 [GitHub Issues](https://github.com/Kilo-Org/kilocode/issues)
2. **提交 PR**：查找问题并提交修复
3. **编写测试**：提高代码覆盖率
4. **改进文档**：访问 [kilo.ai/docs](https://kilo.ai/docs)
5. **建议新功能**：使用 [GitHub Discussions](https://github.com/Kilo-Org/kilocode/discussions/categories/ideas)
6. **实现新功能**：在 [Discord](https://discord.gg/Ja6BkfyTzJ) 上获得支持

详细信息请参阅 [CONTRIBUTING.md](CONTRIBUTING.md) 和 [DEVELOPMENT.md](DEVELOPMENT.md)。

## 社区资源

- **Discord**：https://discord.gg/Ja6BkfyTzJ
- **Twitter/X**：[@kilocode](https://x.com/kilocode)
- **博客**：https://blog.kilo.ai
- **Reddit**：[r/kilocode](https://www.reddit.com/r/kilocode/)
- **官网**：https://kilo.ai

## 相关文档

- [DEVELOPMENT.md](DEVELOPMENT.md) - 详细的开发指南
- [CONTRIBUTING.md](CONTRIBUTING.md) - 贡献指南
- [AGENTS.md](AGENTS.md) - 模式特定规则和代码质量规则
- [CHANGELOG.md](CHANGELOG.md) - 版本更新日志
- [skills_mechanism_technical_document.md](skills_mechanism_technical_document.md) - 技能机制技术文档

## 许可证

本项目采用 [LICENSE](LICENSE) 中规定的许可证。

---

**注意**：本文件由 iFlow CLI 自动生成，用于为 AI 代理提供项目上下文。如需更新，请运行相应的上下文生成命令。
