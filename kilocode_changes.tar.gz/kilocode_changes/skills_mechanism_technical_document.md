# DeepAgents Skills 机制技术实现文档

## 概述

DeepAgents的Skills系统实现了Anthropic的"Agent Skills"设计模式，采用渐进式披露(progressive disclosure)理念。该系统允许用户通过自定义技能扩展agent的能力，而无需修改核心代码。

## 架构设计

### 核心组件

```mermaid
graph TB
    A[Skills System] --> B[Skills Loader Module]
    A --> C[Skills Middleware]
    A --> D[CLI Command Interface]
    A --> E[Security Validation]
    
    B --> F[User Skills Directory<br/>~/.deepagents/agent/skills/]
    B --> G[Project Skills Directory<br/>.deepagents/skills/]
    
    C --> H[System Prompt Injection]
    C --> I[State Management]
    C --> J[Progressive Disclosure]
    
    D --> K[Skills List Command]
    D --> L[Skills Create Command]
    D --> M[Skills Info Command]
    
    E --> N[Path Validation]
    E --> O[Name Sanitization]
    E --> P[Symlink Protection]
```

### 设计原则

1. **渐进式披露**: Agent知道skills存在，但只在需要时读取完整指令
2. **模块化**: 每个skill是独立的目录，包含SKILL.md和支持文件
3. **层级覆盖**: 项目skills覆盖用户skills（同名时）
4. **安全性**: 多重防护防止路径遍历和注入攻击

## 实现细节

### Skills加载机制

**加载流程**:
```python
def list_skills(user_skills_dir, project_skills_dir):
    # 1. 扫描用户skills目录
    user_skills = _scan_directory(user_skills_dir, "user")
    
    # 2. 扫描项目skills目录  
    project_skills = _scan_directory(project_skills_dir, "project")
    
    # 3. 合并并覆盖（项目skills优先）
    all_skills = {**user_skills, **project_skills}
    return list(all_skills.values())
```

**SKILL.md文件结构**:
```markdown
---
name: web-research
description: Structured approach to conducting thorough web research
---

# Web Research Skill

## When to Use
- User asks you to research a topic
- Need comprehensive information gathering

## How to Use
### Step 1: Planning
- Define research objectives
- Identify key search terms

### Step 2: Execution  
- Use web_search tool with targeted queries
- Gather multiple sources
```

### 中间件集成

**SkillsMiddleware功能**:
- **会话启动时**: 加载所有skills元数据到state
- **每次模型调用**: 注入skills信息到系统提示
- **状态管理**: 维护`skills_metadata`状态变量

**系统提示注入**:
```python
def wrap_model_call(self, request, handler):
    skills_metadata = request.state.get("skills_metadata", [])
    skills_section = self._format_skills_section(skills_metadata)
    
    # 注入到系统提示
    system_prompt = request.system_prompt + "\n\n" + skills_section
    return handler(request.override(system_prompt=system_prompt))
```

### CLI管理命令

**命令结构**:
- `deepagents skills list` - 列出可用skills
- `deepagents skills create <name>` - 创建新skill模板
- `deepagents skills info <name>` - 查看skill详细信息

**创建命令示例**:
```bash
# 创建用户级skill
deepagents skills create web-research

# 创建项目级skill  
deepagents skills create project-tool --project
```

## 安全机制

### 多层防护

1. **路径验证**:
```python
def _is_safe_path(path, base_dir):
    # 解析规范路径并检查是否在base_dir内
    resolved_path = path.resolve()
    resolved_base = base_dir.resolve()
    return resolved_path.is_relative_to(resolved_base)
```

2. **名称验证**:
```python
def _validate_name(name):
    # 只允许字母、数字、连字符、下划线
    if not re.match(r"^[a-zA-Z0-9_-]+$", name):
        return False, "Invalid characters"
    # 防止路径遍历
    if ".." in name or "/" in name or "\\" in name:
        return False, "Path traversal attempt"
    return True, ""
```

3. **文件大小限制**: 最大10MB的SKILL.md文件
4. **符号链接检查**: 防止符号链接指向外部目录

## 与Claude Code Skills的对比

### 相似之处

1. **渐进式披露模式**: 两者都采用知道存在→需要时读取的设计
2. **技能发现**: 自动扫描预定义目录结构
3. **元数据驱动**: 使用YAML frontmatter定义技能基本信息
4. **支持文件**: 允许技能包含辅助脚本和配置文件

### DeepAgents特有功能

1. **两级存储**: 用户级 + 项目级skills目录
2. **项目集成**: 自动检测.git目录加载项目skills
3. **CLI管理**: 完整的命令行管理界面
4. **安全强化**: 多重安全验证机制
5. **中间件架构**: 深度集成到LangGraph执行流程

## 使用示例

### 技能创建

```bash
# 创建新skill
deepagents skills create data-analysis

# 编辑SKILL.md
nano ~/.deepagents/agent/skills/data-analysis/SKILL.md

# 添加支持脚本
cp analysis_script.py ~/.deepagents/agent/skills/data-analysis/
```

### 技能使用流程

1. **Agent启动**: 加载skills元数据到系统提示
2. **用户请求**: "请分析这个数据集"
3. **技能识别**: Agent发现data-analysis技能适用
4. **读取指令**: 使用read_file读取完整SKILL.md
5. **执行工作流**: 按照技能指令执行分析任务
6. **使用支持文件**: 调用技能目录中的分析脚本

## 最佳实践

### 技能设计

1. **专注单一领域**: 每个技能解决特定类型任务
2. **清晰文档**: 提供详细的使用说明和示例
3. **完整元数据**: 确保name和description字段准确
4. **支持文件**: 包含必要的脚本和配置文件

### 安全考虑

1. **验证输入**: 所有用户提供的技能名称必须验证
2. **路径安全**: 确保技能路径在允许范围内
3. **文件限制**: 限制SKILL.md文件大小
4. **符号链接**: 检查符号链接安全性

## 扩展性

### 自定义集成

开发者可以通过以下方式扩展系统:

1. **添加新技能**: 创建SKILL.md文件和支持脚本
2. **修改中间件**: 自定义SkillsMiddleware行为
3. **扩展CLI**: 添加新的管理命令
4. **集成外部系统**: 连接其他技能管理系统

### 性能优化

1. **缓存机制**: 缓存已解析的skills元数据
2. **懒加载**: 只在需要时读取完整技能内容
3. **增量更新**: 监听目录变化自动更新技能列表

## 结论

DeepAgents的Skills系统提供了一个强大而安全的机制来扩展agent能力。它结合了Anthropic的设计理念和实际工程实践，既保证了易用性又确保了安全性。系统的模块化设计和渐进式披露模式使其非常适合复杂的现实世界应用场景。