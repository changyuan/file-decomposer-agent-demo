export interface SkillMetadata {
	name: string
	description: string
	version?: string
	author?: string
	tags?: string[]
	path: string
	source: "user" | "project"
	enabled: boolean
}

export interface SkillContent {
	metadata: SkillMetadata
	content: string
	supportFiles: string[]
}

export interface ValidationResult {
	valid: boolean
	error?: string
}

export interface SkillsConfig {
	enabled: boolean
	userDirectory: string
	projectDirectory: string
	autoLoad: boolean
	maxFileSize: number
}
