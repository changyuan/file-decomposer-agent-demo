# Claude Code Skills 功能实现规格文档

## 1. 项目概述

### 1.1 目标
在 Kilo Code VS Code 扩展中实现 Claude Code Skills 功能，允许用户通过自定义技能扩展 AI 代理的能力。

### 1.2 范围
- ✅ **实现范围**: VS Code 扩展端 (`src/`, `webview-ui/`)
- ❌ **不实现**: CLI 端 (`cli/`)
- ✅ **共享类型**: 在 `packages/types/` 中添加必要的类型定义

### 1.3 设计原则
1. **渐进式披露**: Agent 知道 skills 存在，但只在需要时读取完整指令
2. **模块化**: 每个 skill 是独立的目录，包含 SKILL.md 和支持文件
3. **层级覆盖**: 项目 skills 覆盖用户 skills（同名时）
4. **安全性**: 多重防护防止路径遍历和注入攻击
5. **无侵入性**: 不影响现有功能，可选启用

---

## 2. 架构设计

### 2.1 目录结构

```
用户级 Skills:
~/.kilocode/skills/
├── web-research/
│   ├── SKILL.md           # 技能定义文件
│   ├── config.json        # 可选配置
│   └── scripts/           # 支持脚本
│       └── search.py
└── data-analysis/
    └── SKILL.md

项目级 Skills:
<project-root>/.kilocode/skills/
├── project-tool/
│   └── SKILL.md
└── custom-workflow/
    └── SKILL.md
```

### 2.2 SKILL.md 文件格式

```markdown
---
name: web-research
description: Structured approach to conducting thorough web research
version: 1.0.0
author: user@example.com
tags: [research, web, information-gathering]
---

# Web Research Skill

## When to Use
- User asks you to research a topic
- Need comprehensive information gathering
- Require multiple source verification

## How to Use

### Step 1: Planning
- Define research objectives
- Identify key search terms
- Determine information sources

### Step 2: Execution  
- Use web_search tool with targeted queries
- Gather information from multiple sources
- Cross-reference findings

### Step 3: Synthesis
- Organize collected information
- Identify patterns and insights
- Present findings in structured format

## Examples

### Example 1: Technology Research
**User Request**: "Research the latest developments in quantum computing"

**Execution**:
1. Search for "quantum computing 2024 breakthroughs"
2. Identify key players (IBM, Google, IonQ)
3. Gather technical specifications
4. Compile timeline of recent achievements

## Best Practices
- Always verify information from multiple sources
- Include publication dates in citations
- Note any conflicting information
- Provide links to primary sources
```

### 2.3 组件架构

```mermaid
graph TB
    A[VS Code Extension] --> B[Skills Manager]
    B --> C[Skills Loader]
    B --> D[Skills Validator]
    B --> E[Skills Cache]
    
    C --> F[User Skills Dir<br/>~/.kilocode/skills/]
    C --> G[Project Skills Dir<br/>.kilocode/skills/]
    
    B --> H[System Prompt Injector]
    H --> I[Task.getSystemPrompt]
    
    J[Webview UI] --> K[Skills Selector]
    J --> L[Skills Manager UI]
    
    K --> M[WebviewMessageHandler]
    M --> B
```

---

## 3. 核心模块设计

### 3.1 Skills Manager (`src/core/skills/SkillsManager.ts`)

**职责**:
- 加载和管理所有 skills
- 提供 skills 元数据
- 处理 skills 的启用/禁用状态
- 缓存已解析的 skills

**接口设计**:

```typescript
interface SkillMetadata {
  name: string
  description: string
  version?: string
  author?: string
  tags?: string[]
  path: string
  source: 'user' | 'project'
  enabled: boolean
}

interface SkillContent {
  metadata: SkillMetadata
  content: string  // SKILL.md 的完整内容
  supportFiles: string[]  // 支持文件列表
}

class SkillsManager {
  private userSkillsDir: string
  private projectSkillsDir: string | null
  private cache: Map<string, SkillContent>
  private enabledSkills: Set<string>
  
  constructor(cwd: string)
  
  // 加载所有 skills 的元数据
  async loadSkillsMetadata(): Promise<SkillMetadata[]>
  
  // 读取特定 skill 的完整内容
  async getSkillContent(name: string): Promise<SkillContent | null>
  
  // 启用/禁用 skill
  async enableSkill(name: string): Promise<void>
  async disableSkill(name: string): Promise<void>
  
  // 获取已启用的 skills
  getEnabledSkills(): SkillMetadata[]
  
  // 创建新 skill
  async createSkill(name: string, location: 'user' | 'project'): Promise<void>
  
  // 删除 skill
  async deleteSkill(name: string): Promise<void>
  
  // 清除缓存
  clearCache(): void
}
```

### 3.2 Skills Loader (`src/core/skills/SkillsLoader.ts`)

**职责**:
- 扫描目录查找 skills
- 解析 SKILL.md 文件
- 验证 skill 格式
- 处理层级覆盖逻辑

**实现细节**:

```typescript
class SkillsLoader {
  // 扫描目录
  private async scanDirectory(dir: string, source: 'user' | 'project'): Promise<SkillMetadata[]> {
    // 1. 读取目录
    // 2. 过滤有效的 skill 目录（包含 SKILL.md）
    // 3. 解析每个 SKILL.md 的 frontmatter
    // 4. 返回元数据数组
  }
  
  // 解析 SKILL.md
  private async parseSkillFile(path: string): Promise<SkillMetadata | null> {
    // 1. 读取文件内容
    // 2. 解析 YAML frontmatter
    // 3. 验证必需字段（name, description）
    // 4. 返回元数据对象
  }
  
  // 合并用户和项目 skills（项目优先）
  private mergeSkills(userSkills: SkillMetadata[], projectSkills: SkillMetadata[]): SkillMetadata[] {
    // 使用 Map 按 name 合并，项目 skills 覆盖用户 skills
  }
}
```

### 3.3 Skills Validator (`src/core/skills/SkillsValidator.ts`)

**职责**:
- 验证 skill 名称安全性
- 验证路径安全性
- 检查文件大小限制
- 防止符号链接攻击

**安全检查**:

```typescript
class SkillsValidator {
  private readonly MAX_SKILL_FILE_SIZE = 10 * 1024 * 1024  // 10MB
  private readonly VALID_NAME_PATTERN = /^[a-zA-Z0-9_-]+$/
  
  // 验证 skill 名称
  validateSkillName(name: string): ValidationResult {
    // 1. 检查字符合法性
    // 2. 防止路径遍历（../, ..\）
    // 3. 检查长度限制
  }
  
  // 验证路径安全
  validatePath(path: string, baseDir: string): boolean {
    // 1. 解析规范路径
    // 2. 确保路径在 baseDir 内
    // 3. 检查符号链接
  }
  
  // 验证文件大小
  async validateFileSize(path: string): Promise<boolean> {
    // 检查文件大小是否在限制内
  }
  
  // 验证 SKILL.md 格式
  validateSkillFormat(content: string): ValidationResult {
    // 1. 检查 frontmatter 存在
    // 2. 验证必需字段
    // 3. 检查内容结构
  }
}
```

### 3.4 System Prompt Injector (`src/core/skills/SystemPromptInjector.ts`)

**职责**:
- 生成 skills 相关的系统提示
- 实现渐进式披露
- 格式化 skills 信息

**提示格式**:

```typescript
class SystemPromptInjector {
  // 生成 skills 部分的系统提示
  generateSkillsPrompt(skills: SkillMetadata[]): string {
    return `
# Available Skills

You have access to the following specialized skills that can help you complete tasks more effectively:

${skills.map(skill => `
## ${skill.name}
${skill.description}

To use this skill, read the full instructions:
- Use the read_file tool to read: ${skill.path}/SKILL.md
`).join('\n')}

## When to Use Skills
- Identify if the user's request matches any skill's description
- Read the full skill instructions before using it
- Follow the skill's workflow precisely
- Use skills to maintain consistency and best practices
`
  }
  
  // 注入到现有系统提示
  injectIntoSystemPrompt(basePrompt: string, skills: SkillMetadata[]): string {
    if (skills.length === 0) return basePrompt
    
    const skillsSection = this.generateSkillsPrompt(skills)
    return `${basePrompt}\n\n${skillsSection}`
  }
}
```

---

## 4. 集成点

### 4.1 系统提示集成

**修改位置**: `src/core/task/Task.ts`

**修改方案**:

```typescript
// 在 Task 类中添加
private skillsManager: SkillsManager

constructor(/* 现有参数 */) {
  // 现有初始化代码
  this.skillsManager = new SkillsManager(this.cwd)
}

// 修改 getSystemPrompt 方法
async getSystemPrompt(): Promise<string> {
  const basePrompt = await SYSTEM_PROMPT(
    this.cwd,
    this.api.getModel().info,
    this.supportsComputerUse,
    this.mode
  )
  
  // 注入 skills 信息
  const enabledSkills = this.skillsManager.getEnabledSkills()
  if (enabledSkills.length > 0) {
    const injector = new SystemPromptInjector()
    return injector.injectIntoSystemPrompt(basePrompt, enabledSkills)
  }
  
  return basePrompt
}
```

### 4.2 Webview 消息处理

**修改位置**: `src/core/webview/webviewMessageHandler.ts`

**新增消息类型**:

```typescript
// 在 packages/types/src/webview.ts 添加
export interface WebviewMessage {
  // 现有消息类型...
  
  // Skills 相关消息
  listSkills: undefined
  getSkillContent: { name: string }
  enableSkill: { name: string }
  disableSkill: { name: string }
  createSkill: { name: string; location: 'user' | 'project' }
  deleteSkill: { name: string }
  refreshSkills: undefined
}
```

**处理器实现**:

```typescript
// 在 webviewMessageHandler.ts 的 switch 语句中添加
case "listSkills": {
  const skills = await this.clineProvider.skillsManager.loadSkillsMetadata()
  this.postMessageToWebview({ type: "skillsList", skills })
  break
}

case "getSkillContent": {
  const content = await this.clineProvider.skillsManager.getSkillContent(message.name)
  this.postMessageToWebview({ type: "skillContent", content })
  break
}

case "enableSkill": {
  await this.clineProvider.skillsManager.enableSkill(message.name)
  this.postMessageToWebview({ type: "skillEnabled", name: message.name })
  break
}

case "disableSkill": {
  await this.clineProvider.skillsManager.disableSkill(message.name)
  this.postMessageToWebview({ type: "skillDisabled", name: message.name })
  break
}

case "createSkill": {
  await this.clineProvider.skillsManager.createSkill(message.name, message.location)
  this.postMessageToWebview({ type: "skillCreated", name: message.name })
  break
}

case "deleteSkill": {
  await this.clineProvider.skillsManager.deleteSkill(message.name)
  this.postMessageToWebview({ type: "skillDeleted", name: message.name })
  break
}

case "refreshSkills": {
  this.clineProvider.skillsManager.clearCache()
  const skills = await this.clineProvider.skillsManager.loadSkillsMetadata()
  this.postMessageToWebview({ type: "skillsList", skills })
  break
}
```

### 4.3 VS Code 配置

**修改位置**: `src/package.json`

**新增配置项**:

```json
{
  "contributes": {
    "configuration": {
      "properties": {
        "kilocode.skills.enabled": {
          "type": "boolean",
          "default": true,
          "description": "Enable Claude Code Skills functionality"
        },
        "kilocode.skills.userDirectory": {
          "type": "string",
          "default": "~/.kilocode/skills",
          "description": "Directory for user-level skills"
        },
        "kilocode.skills.projectDirectory": {
          "type": "string",
          "default": ".kilocode/skills",
          "description": "Directory for project-level skills (relative to workspace root)"
        },
        "kilocode.skills.autoLoad": {
          "type": "boolean",
          "default": true,
          "description": "Automatically load skills when starting a task"
        },
        "kilocode.skills.maxFileSize": {
          "type": "number",
          "default": 10485760,
          "description": "Maximum size for SKILL.md files in bytes (default: 10MB)"
        }
      }
    }
  }
}
```

---

## 5. UI 设计

### 5.1 Skills 管理面板

**位置**: 在 Webview UI 中添加新的面板

**组件结构**:

```
webview-ui/src/components/skills/
├── SkillsPanel.tsx          # 主面板
├── SkillsList.tsx           # Skills 列表
├── SkillCard.tsx            # 单个 Skill 卡片
├── SkillDetail.tsx          # Skill 详情视图
├── SkillCreator.tsx         # 创建 Skill 对话框
└── SkillsSettings.tsx       # Skills 设置
```

**SkillsPanel.tsx**:

```tsx
import React, { useState, useEffect } from 'react'
import { vscode } from '../utils/vscode'
import { SkillMetadata } from '@roo-code/types'

export const SkillsPanel: React.FC = () => {
  const [skills, setSkills] = useState<SkillMetadata[]>([])
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    // 加载 skills 列表
    vscode.postMessage({ type: 'listSkills' })
    
    // 监听消息
    const handleMessage = (event: MessageEvent) => {
      const message = event.data
      switch (message.type) {
        case 'skillsList':
          setSkills(message.skills)
          setLoading(false)
          break
        // 其他消息处理...
      }
    }
    
    window.addEventListener('message', handleMessage)
    return () => window.removeEventListener('message', handleMessage)
  }, [])
  
  return (
    <div className="skills-panel">
      <div className="skills-header">
        <h2>Claude Code Skills</h2>
        <button onClick={() => vscode.postMessage({ type: 'createSkill' })}>
          + New Skill
        </button>
      </div>
      
      <div className="skills-content">
        <SkillsList 
          skills={skills}
          selectedSkill={selectedSkill}
          onSelectSkill={setSelectedSkill}
        />
        
        {selectedSkill && (
          <SkillDetail skillName={selectedSkill} />
        )}
      </div>
    </div>
  )
}
```

### 5.2 Skills 选择器

**集成位置**: 在任务开始前显示

**SkillSelector.tsx**:

```tsx
export const SkillSelector: React.FC<{ onSkillsSelected: (skills: string[]) => void }> = ({ 
  onSkillsSelected 
}) => {
  const [availableSkills, setAvailableSkills] = useState<SkillMetadata[]>([])
  const [selectedSkills, setSelectedSkills] = useState<Set<string>>(new Set())
  
  const handleToggleSkill = (skillName: string) => {
    const newSelected = new Set(selectedSkills)
    if (newSelected.has(skillName)) {
      newSelected.delete(skillName)
    } else {
      newSelected.add(skillName)
    }
    setSelectedSkills(newSelected)
  }
  
  const handleConfirm = () => {
    onSkillsSelected(Array.from(selectedSkills))
  }
  
  return (
    <div className="skill-selector">
      <h3>Select Skills for this Task</h3>
      <div className="skills-grid">
        {availableSkills.map(skill => (
          <div 
            key={skill.name}
            className={`skill-card ${selectedSkills.has(skill.name) ? 'selected' : ''}`}
            onClick={() => handleToggleSkill(skill.name)}
          >
            <div className="skill-name">{skill.name}</div>
            <div className="skill-description">{skill.description}</div>
            {skill.tags && (
              <div className="skill-tags">
                {skill.tags.map(tag => (
                  <span key={tag} className="tag">{tag}</span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <button onClick={handleConfirm}>Continue with Selected Skills</button>
    </div>
  )
}
```

---

## 6. 实现计划

### 阶段 1: 基础架构（第 1-2 天）

**目标**: 实现核心的 Skills 管理功能

**任务**:
1. ✅ 创建 `src/core/skills/` 目录结构
2. ✅ 实现 `SkillsValidator.ts`（安全验证）
3. ✅ 实现 `SkillsLoader.ts`（加载和解析）
4. ✅ 实现 `SkillsManager.ts`（管理和缓存）
5. ✅ 编写单元测试

**验收标准**:
- [ ] 能够扫描用户和项目 skills 目录
- [ ] 能够正确解析 SKILL.md 文件
- [ ] 安全验证通过所有测试用例
- [ ] 单元测试覆盖率 > 80%

### 阶段 2: 系统提示集成（第 3 天）

**目标**: 将 Skills 信息注入到系统提示中

**任务**:
1. ✅ 实现 `SystemPromptInjector.ts`
2. ✅ 修改 `Task.ts` 的 `getSystemPrompt()` 方法
3. ✅ 在 `ClineProvider.ts` 中初始化 `SkillsManager`
4. ✅ 测试系统提示生成

**验收标准**:
- [ ] 系统提示包含已启用的 skills 信息
- [ ] 渐进式披露正确实现
- [ ] 不影响现有功能

### 阶段 3: 类型定义（第 3 天）

**目标**: 添加共享类型定义

**任务**:
1. ✅ 在 `packages/types/src/` 添加 `skills.ts`
2. ✅ 定义 `SkillMetadata`, `SkillContent` 等接口
3. ✅ 在 `webview.ts` 添加 Skills 相关消息类型
4. ✅ 更新类型导出

**验收标准**:
- [ ] 类型定义完整且文档齐全
- [ ] VS Code 扩展和 Webview UI 都能使用这些类型
- [ ] TypeScript 编译无错误

### 阶段 4: Webview 消息处理（第 4 天）

**目标**: 实现 UI 和后端的通信

**任务**:
1. ✅ 在 `webviewMessageHandler.ts` 添加 Skills 消息处理
2. ✅ 实现所有 Skills 相关的消息处理器
3. ✅ 添加错误处理和日志
4. ✅ 测试消息流

**验收标准**:
- [ ] 所有 Skills 操作都能通过消息正确执行
- [ ] 错误能够正确传递到 UI
- [ ] 消息处理有适当的日志记录

### 阶段 5: UI 组件（第 5-6 天）

**目标**: 实现 Skills 管理界面

**任务**:
1. ✅ 创建 `webview-ui/src/components/skills/` 目录
2. ✅ 实现 `SkillsPanel.tsx`（主面板）
3. ✅ 实现 `SkillsList.tsx`（列表视图）
4. ✅ 实现 `SkillCard.tsx`（卡片组件）
5. ✅ 实现 `SkillDetail.tsx`（详情视图）
6. ✅ 实现 `SkillCreator.tsx`（创建对话框）
7. ✅ 添加 CSS 样式
8. ✅ 集成到主 UI

**验收标准**:
- [ ] UI 美观且符合 VS Code 设计规范
- [ ] 所有 Skills 操作都有对应的 UI
- [ ] 响应式设计，适配不同窗口大小
- [ ] 加载状态和错误状态有适当的反馈

### 阶段 6: VS Code 配置（第 7 天）

**目标**: 添加配置选项

**任务**:
1. ✅ 在 `src/package.json` 添加配置项
2. ✅ 实现配置读取逻辑
3. ✅ 添加配置验证
4. ✅ 更新文档

**验收标准**:
- [ ] 所有配置项都能在 VS Code 设置中访问
- [ ] 配置更改能够实时生效
- [ ] 配置有合理的默认值

### 阶段 7: 测试和优化（第 8-9 天）

**目标**: 全面测试和性能优化

**任务**:
1. ✅ 编写集成测试
2. ✅ 进行端到端测试
3. ✅ 性能测试和优化
4. ✅ 修复发现的 bug
5. ✅ 代码审查和重构

**验收标准**:
- [ ] 所有测试通过
- [ ] 无明显性能问题
- [ ] 代码质量符合项目标准
- [ ] 无安全漏洞

### 阶段 8: 文档和示例（第 10 天）

**目标**: 完善文档和创建示例

**任务**:
1. ✅ 编写用户文档
2. ✅ 创建示例 Skills
3. ✅ 更新 README
4. ✅ 录制演示视频（可选）

**验收标准**:
- [ ] 文档清晰完整
- [ ] 至少有 3 个示例 Skills
- [ ] 用户能够根据文档独立使用功能

---

## 7. 测试策略

### 7.1 单元测试

**测试框架**: Vitest

**测试文件**:
```
src/core/skills/
├── SkillsValidator.spec.ts
├── SkillsLoader.spec.ts
├── SkillsManager.spec.ts
└── SystemPromptInjector.spec.ts
```

**测试用例示例**:

```typescript
// SkillsValidator.spec.ts
describe('SkillsValidator', () => {
  describe('validateSkillName', () => {
    it('should accept valid skill names', () => {
      const validator = new SkillsValidator()
      expect(validator.validateSkillName('web-research').valid).toBe(true)
      expect(validator.validateSkillName('data_analysis').valid).toBe(true)
      expect(validator.validateSkillName('tool123').valid).toBe(true)
    })
    
    it('should reject invalid skill names', () => {
      const validator = new SkillsValidator()
      expect(validator.validateSkillName('../etc/passwd').valid).toBe(false)
      expect(validator.validateSkillName('skill/name').valid).toBe(false)
      expect(validator.validateSkillName('skill name').valid).toBe(false)
    })
  })
  
  describe('validatePath', () => {
    it('should detect path traversal attempts', () => {
      const validator = new SkillsValidator()
      const baseDir = '/home/user/.kilocode/skills'
      
      expect(validator.validatePath(
        '/home/user/.kilocode/skills/web-research',
        baseDir
      )).toBe(true)
      
      expect(validator.validatePath(
        '/home/user/.kilocode/skills/../../../etc/passwd',
        baseDir
      )).toBe(false)
    })
  })
})
```

### 7.2 集成测试

**测试场景**:
1. 加载用户和项目 skills
2. 项目 skills 覆盖用户 skills
3. 启用/禁用 skills
4. 创建新 skill
5. 删除 skill
6. 系统提示注入

### 7.3 E2E 测试

**测试流程**:
1. 启动 VS Code 扩展
2. 创建测试项目
3. 添加 skills
4. 启动任务并验证 skills 被加载
5. 验证 UI 交互

---

## 8. 安全考虑

### 8.1 路径遍历防护

```typescript
// 确保路径在允许的目录内
function isPathSafe(path: string, baseDir: string): boolean {
  const resolvedPath = fs.realpathSync(path)
  const resolvedBase = fs.realpathSync(baseDir)
  return resolvedPath.startsWith(resolvedBase)
}
```

### 8.2 文件大小限制

```typescript
// 限制 SKILL.md 文件大小
const MAX_SKILL_FILE_SIZE = 10 * 1024 * 1024  // 10MB

async function readSkillFile(path: string): Promise<string> {
  const stats = await fs.stat(path)
  if (stats.size > MAX_SKILL_FILE_SIZE) {
    throw new Error('Skill file too large')
  }
  return fs.readFile(path, 'utf-8')
}
```

### 8.3 名称验证

```typescript
// 只允许安全的字符
const VALID_SKILL_NAME = /^[a-zA-Z0-9_-]+$/

function validateSkillName(name: string): boolean {
  if (!VALID_SKILL_NAME.test(name)) return false
  if (name.includes('..')) return false
  if (name.includes('/') || name.includes('\\')) return false
  return true
}
```

### 8.4 符号链接检查

```typescript
// 防止符号链接指向外部
async function checkSymlink(path: string, baseDir: string): Promise<boolean> {
  const stats = await fs.lstat(path)
  if (stats.isSymbolicLink()) {
    const realPath = await fs.realpath(path)
    return isPathSafe(realPath, baseDir)
  }
  return true
}
```

---

## 9. 性能优化

### 9.1 缓存策略

```typescript
class SkillsManager {
  private cache: Map<string, SkillContent> = new Map()
  private cacheExpiry: Map<string, number> = new Map()
  private readonly CACHE_TTL = 5 * 60 * 1000  // 5 分钟
  
  async getSkillContent(name: string): Promise<SkillContent | null> {
    // 检查缓存
    const cached = this.cache.get(name)
    const expiry = this.cacheExpiry.get(name)
    
    if (cached && expiry && Date.now() < expiry) {
      return cached
    }
    
    // 加载并缓存
    const content = await this.loadSkillContent(name)
    if (content) {
      this.cache.set(name, content)
      this.cacheExpiry.set(name, Date.now() + this.CACHE_TTL)
    }
    
    return content
  }
}
```

### 9.2 懒加载

- 只在需要时读取完整的 SKILL.md 内容
- 元数据在启动时加载，内容按需加载
- 支持文件列表延迟加载

### 9.3 并行加载

```typescript
async loadSkillsMetadata(): Promise<SkillMetadata[]> {
  const [userSkills, projectSkills] = await Promise.all([
    this.loadUserSkills(),
    this.loadProjectSkills()
  ])
  
  return this.mergeSkills(userSkills, projectSkills)
}
```

---

## 10. 示例 Skills

### 10.1 Web Research Skill

**文件**: `~/.kilocode/skills/web-research/SKILL.md`

```markdown
---
name: web-research
description: Structured approach to conducting thorough web research
version: 1.0.0
tags: [research, web, information-gathering]
---

# Web Research Skill

## When to Use
- User asks you to research a topic
- Need comprehensive information gathering
- Require multiple source verification

## How to Use

### Step 1: Planning
1. Define research objectives
2. Identify key search terms
3. Determine information sources

### Step 2: Execution
1. Use `web_search` tool with targeted queries
2. Gather information from multiple sources
3. Cross-reference findings

### Step 3: Synthesis
1. Organize collected information
2. Identify patterns and insights
3. Present findings in structured format

## Best Practices
- Always verify information from multiple sources
- Include publication dates in citations
- Note any conflicting information
- Provide links to primary sources
```

### 10.2 Code Review Skill

**文件**: `~/.kilocode/skills/code-review/SKILL.md`

```markdown
---
name: code-review
description: Systematic approach to reviewing code for quality, security, and best practices
version: 1.0.0
tags: [code-review, quality, security]
---

# Code Review Skill

## When to Use
- User asks you to review code
- Before merging changes
- When improving code quality

## Review Checklist

### 1. Code Quality
- [ ] Code follows project conventions
- [ ] Naming is clear and descriptive
- [ ] Functions are focused and single-purpose
- [ ] No code duplication

### 2. Security
- [ ] No hardcoded credentials
- [ ] Input validation present
- [ ] SQL injection prevention
- [ ] XSS prevention

### 3. Performance
- [ ] No obvious performance bottlenecks
- [ ] Efficient algorithms used
- [ ] Proper resource cleanup

### 4. Testing
- [ ] Unit tests present
- [ ] Edge cases covered
- [ ] Tests are meaningful

## Output Format

Provide feedback in this structure:
1. **Summary**: Overall assessment
2. **Critical Issues**: Must-fix items
3. **Suggestions**: Nice-to-have improvements
4. **Positive Notes**: What was done well
```

### 10.3 API Design Skill

**文件**: `.kilocode/skills/api-design/SKILL.md`

```markdown
---
name: api-design
description: Best practices for designing RESTful APIs
version: 1.0.0
tags: [api, rest, design]
---

# API Design Skill

## When to Use
- Designing new API endpoints
- Refactoring existing APIs
- API documentation

## Design Principles

### 1. Resource Naming
- Use nouns, not verbs
- Use plural for collections: `/users`, `/posts`
- Use hierarchical structure: `/users/{id}/posts`

### 2. HTTP Methods
- GET: Retrieve resources
- POST: Create new resources
- PUT: Update entire resource
- PATCH: Partial update
- DELETE: Remove resource

### 3. Status Codes
- 200: Success
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 404: Not Found
- 500: Server Error

### 4. Response Format
```json
{
  "data": { /* resource data */ },
  "meta": {
    "timestamp": "2024-01-01T00:00:00Z",
    "version": "1.0"
  }
}
```

## Checklist
- [ ] Consistent naming conventions
- [ ] Proper HTTP methods
- [ ] Appropriate status codes
- [ ] Versioning strategy
- [ ] Error handling
- [ ] Documentation
```

---

## 11. 国际化 (i18n)

### 11.1 UI 文本

**文件**: `src/package.nls.json`

```json
{
  "kilocode.skills.enabled": "Enable Claude Code Skills",
  "kilocode.skills.userDirectory": "User Skills Directory",
  "kilocode.skills.projectDirectory": "Project Skills Directory",
  "kilocode.skills.panel.title": "Claude Code Skills",
  "kilocode.skills.create.button": "New Skill",
  "kilocode.skills.refresh.button": "Refresh",
  "kilocode.skills.enable.button": "Enable",
  "kilocode.skills.disable.button": "Disable",
  "kilocode.skills.delete.button": "Delete",
  "kilocode.skills.error.invalidName": "Invalid skill name",
  "kilocode.skills.error.notFound": "Skill not found",
  "kilocode.skills.error.loadFailed": "Failed to load skill"
}
```

### 11.2 中文翻译

**文件**: `src/package.nls.zh-cn.json`

```json
{
  "kilocode.skills.enabled": "启用 Claude Code Skills",
  "kilocode.skills.userDirectory": "用户技能目录",
  "kilocode.skills.projectDirectory": "项目技能目录",
  "kilocode.skills.panel.title": "Claude Code 技能",
  "kilocode.skills.create.button": "新建技能",
  "kilocode.skills.refresh.button": "刷新",
  "kilocode.skills.enable.button": "启用",
  "kilocode.skills.disable.button": "禁用",
  "kilocode.skills.delete.button": "删除",
  "kilocode.skills.error.invalidName": "无效的技能名称",
  "kilocode.skills.error.notFound": "未找到技能",
  "kilocode.skills.error.loadFailed": "加载技能失败"
}
```

---

## 12. 文档

### 12.1 用户文档

**文件**: `docs/skills-guide.md`

**内容大纲**:
1. 什么是 Claude Code Skills
2. 如何创建 Skill
3. Skill 文件格式
4. 如何使用 Skills
5. 最佳实践
6. 常见问题

### 12.2 开发者文档

**文件**: `docs/skills-api.md`

**内容大纲**:
1. 架构概述
2. API 参考
3. 扩展 Skills 系统
4. 安全考虑
5. 测试指南

---

## 13. 发布计划

### 13.1 Alpha 版本（内部测试）
- 基础功能完成
- 核心测试通过
- 内部团队测试

### 13.2 Beta 版本（公开测试）
- 所有功能完成
- 文档齐全
- 邀请用户测试

### 13.3 正式版本
- 所有 bug 修复
- 性能优化完成
- 正式发布到 Marketplace

---

## 14. 未来扩展

### 14.1 Skills 市场
- 创建 Skills 分享平台
- 支持从市场安装 Skills
- Skills 评分和评论系统

### 14.2 Skills 模板
- 提供更多内置模板
- 支持自定义模板
- 模板生成器

### 14.3 高级功能
- Skills 依赖管理
- Skills 版本控制
- Skills 自动更新
- Skills 性能分析

---

## 15. 风险和缓解

### 15.1 安全风险
**风险**: 恶意 Skills 可能执行危险操作
**缓解**: 
- 严格的路径验证
- 文件大小限制
- 代码审查机制
- 用户权限控制

### 15.2 性能风险
**风险**: 大量 Skills 可能影响启动性能
**缓解**:
- 懒加载机制
- 缓存策略
- 异步加载
- 性能监控

### 15.3 兼容性风险
**风险**: 可能与现有功能冲突
**缓解**:
- 充分的集成测试
- 向后兼容设计
- 功能开关
- 回滚机制

---

## 16. 成功指标

### 16.1 技术指标
- [ ] 单元测试覆盖率 > 80%
- [ ] 集成测试通过率 100%
- [ ] Skills 加载时间 < 100ms
- [ ] 内存占用增加 < 50MB

### 16.2 用户指标
- [ ] 用户采用率 > 20%
- [ ] 平均每用户创建 Skills 数 > 2
- [ ] 用户满意度 > 4.0/5.0
- [ ] Bug 报告 < 5 个/周

---

## 17. 参考资料

### 17.1 相关文档
- [Anthropic Agent Skills 设计模式](https://docs.anthropic.com/en/docs/build-with-claude/agent-skills)
- [VS Code Extension API](https://code.visualstudio.com/api)
- [Kilo Code 项目文档](../README.md)

### 17.2 相关代码
- `src/core/task/Task.ts` - 任务执行
- `src/core/prompts/system.ts` - 系统提示
- `src/core/webview/webviewMessageHandler.ts` - 消息处理

---

## 附录 A: 术语表

| 术语 | 定义 |
|------|------|
| Skill | 一个独立的能力模块，包含特定任务的指令和支持文件 |
| SKILL.md | Skill 的定义文件，包含元数据和使用说明 |
| 渐进式披露 | Agent 先知道 Skill 存在，需要时再读取完整内容的设计模式 |
| 层级覆盖 | 项目级 Skills 优先于用户级 Skills 的机制 |
| Frontmatter | YAML 格式的元数据块，位于 Markdown 文件开头 |

---

## 附录 B: 文件清单

### 新增文件

**后端**:
- `src/core/skills/SkillsManager.ts`
- `src/core/skills/SkillsLoader.ts`
- `src/core/skills/SkillsValidator.ts`
- `src/core/skills/SystemPromptInjector.ts`
- `src/core/skills/types.ts`
- `src/core/skills/index.ts`

**测试**:
- `src/core/skills/SkillsManager.spec.ts`
- `src/core/skills/SkillsLoader.spec.ts`
- `src/core/skills/SkillsValidator.spec.ts`
- `src/core/skills/SystemPromptInjector.spec.ts`

**前端**:
- `webview-ui/src/components/skills/SkillsPanel.tsx`
- `webview-ui/src/components/skills/SkillsList.tsx`
- `webview-ui/src/components/skills/SkillCard.tsx`
- `webview-ui/src/components/skills/SkillDetail.tsx`
- `webview-ui/src/components/skills/SkillCreator.tsx`
- `webview-ui/src/components/skills/SkillsSettings.tsx`
- `webview-ui/src/components/skills/styles.css`

**类型**:
- `packages/types/src/skills.ts`

**文档**:
- `docs/skills-guide.md`
- `docs/skills-api.md`

**示例**:
- `examples/skills/web-research/SKILL.md`
- `examples/skills/code-review/SKILL.md`
- `examples/skills/api-design/SKILL.md`

### 修改文件

- `src/core/task/Task.ts` - 添加 Skills 集成
- `src/core/webview/webviewMessageHandler.ts` - 添加消息处理
- `src/core/webview/ClineProvider.ts` - 初始化 SkillsManager
- `src/package.json` - 添加配置项
- `packages/types/src/webview.ts` - 添加消息类型
- `packages/types/src/index.ts` - 导出 Skills 类型

---

**文档版本**: 1.0.0  
**创建日期**: 2024-12-17  
**最后更新**: 2024-12-17  
**作者**: iFlow CLI  
**状态**: 待审核
